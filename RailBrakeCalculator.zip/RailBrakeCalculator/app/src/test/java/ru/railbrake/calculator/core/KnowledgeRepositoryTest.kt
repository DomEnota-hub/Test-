package ru.railbrake.calculator.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class KnowledgeRepositoryTest {
    @Test
    fun searchFindsArticleByEquipmentTagIgnoringCase() {
        val results = KnowledgeRepository.search("бса", "Все")

        assertEquals(listOf("vl80-layout"), results.map { it.id })
    }

    @Test
    fun categoryFilterDoesNotLeakArticlesFromOtherSections() {
        val results = KnowledgeRepository.search("", "Тормоза")

        assertTrue(results.isNotEmpty())
        assertTrue(results.all { it.category == "Тормоза" })
    }

    @Test
    fun diagramHotspotsUseValidNormalizedBounds() {
        assertTrue(KnowledgeRepository.vl80LayoutHotspots.size >= 15)
        KnowledgeRepository.vl80LayoutHotspots.forEach { hotspot ->
            assertTrue(hotspot.left in 0f..1f)
            assertTrue(hotspot.top in 0f..1f)
            assertTrue(hotspot.right in 0f..1f)
            assertTrue(hotspot.bottom in 0f..1f)
            assertTrue(hotspot.left < hotspot.right)
            assertTrue(hotspot.top < hotspot.bottom)
        }
    }

    @Test
    fun serviceBrakeRouteHasStartAndCompleteLearningChain() {
        val article = KnowledgeRepository.articles.first { it.id == "vl80-service-brake-route" }
        val route = KnowledgeRepository.vl80ServiceBrakeRoute

        assertTrue(article.hasAirRoute)
        assertTrue(route.start.contains("главные резервуары", ignoreCase = true))
        assertEquals(7, route.steps.size)
        assertTrue(route.steps.any { it.title.contains("№483") })
        assertTrue(route.steps.last().title.contains("№304"))
    }
}
