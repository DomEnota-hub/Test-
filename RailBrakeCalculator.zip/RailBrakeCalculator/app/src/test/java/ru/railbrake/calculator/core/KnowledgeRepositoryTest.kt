package ru.railbrake.calculator.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class KnowledgeRepositoryTest {
    @Test
    fun searchFindsArticleByEquipmentTagIgnoringCase() {
        val results = KnowledgeRepository.search("бса", "Все")

        assertEquals(listOf("vl80-layout"), results.map { it.id })
    }

    @Test
    fun categoryFilterDoesNotLeakArticlesFromOtherSections() {
        val results = KnowledgeRepository.search("", "Тормоза")

        assertTrue(results.isNotEmpty())
        assertTrue(results.all { it.category == "Тормоза" })
    }

    @Test
    fun diagramHotspotsUseValidNormalizedBounds() {
        assertFalse(KnowledgeRepository.vl80LayoutHotspots.isEmpty())
        KnowledgeRepository.vl80LayoutHotspots.forEach { hotspot ->
            assertTrue(hotspot.left in 0f..1f)
            assertTrue(hotspot.top in 0f..1f)
            assertTrue(hotspot.right in 0f..1f)
            assertTrue(hotspot.bottom in 0f..1f)
            assertTrue(hotspot.left < hotspot.right)
            assertTrue(hotspot.top < hotspot.bottom)
        }
    }
}
