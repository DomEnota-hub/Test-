package ru.railbrake.calculator.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class BrakeCalculatorTest {
    @Test
    fun mass_4000t_212axles_12permille() {
        val result = BrakeCalculator.calculateMass(
            MassCalculationInput(
                massTons = 4000.0,
                axleCount = 212,
                slopePermille = 12.0
            )
        )
        assertTrue(result.heavyCategory)
        assertEquals(16, result.requiredShoes)
        assertEquals(40, result.fullManualBrakeAxles)
    }

    @Test
    fun mass_shortage_is_supplemented_not_replaced() {
        val result = BrakeCalculator.calculateMass(
            MassCalculationInput(4000.0, axleCount = 212, slopePermille = 12.0)
        )
        val supplement = BrakeCalculator.calculateMassSupplement(result, availableShoes = 10, axlesPerHandBrakeUnit = 4)
        assertEquals(6, supplement.shoeShortage)
        assertEquals(15, supplement.additionalManualAxles)
        assertEquals(4, supplement.requiredHandBrakeUnits)
        assertEquals(16, supplement.actuallyBrakedAxles)
        assertEquals(1, supplement.reserveManualAxles)
    }

    @Test
    fun consist_771t_34axles_10permille() {
        val result = BrakeCalculator.calculateMass(
            MassCalculationInput(771.0, axleCount = 34, slopePermille = 10.0)
        )
        assertEquals(3, result.requiredShoes)
        assertEquals(7, result.fullManualBrakeAxles)
    }

    @Test
    fun mass_category_boundaries() {
        val light = BrakeCalculator.calculateMass(
            MassCalculationInput(1000.0, manualAxleLoadTons = 9.999, slopePermille = 8.0)
        )
        val exactlyTen = BrakeCalculator.calculateMass(
            MassCalculationInput(1000.0, manualAxleLoadTons = 10.000, slopePermille = 8.0)
        )
        val heavy = BrakeCalculator.calculateMass(
            MassCalculationInput(1000.0, manualAxleLoadTons = 10.001, slopePermille = 8.0)
        )
        assertEquals(false, light.heavyCategory)
        assertEquals(true, exactlyTen.heavyCategory)
        assertEquals(true, heavy.heavyCategory)
        assertEquals(6, light.requiredShoes)
        assertEquals(2, exactlyTen.requiredShoes)
        assertEquals(2, heavy.requiredShoes)
    }

    @Test
    fun exactlyTen_allows_explicit_non_normative_study_comparison() {
        val comparison = BrakeCalculator.calculateMass(
            MassCalculationInput(
                1000.0,
                manualAxleLoadTons = 10.0,
                slopePermille = 8.0,
                educationalTenTonsChoice = TenTonsChoice.LESS_THAN_10
            )
        )
        assertEquals(false, comparison.heavyCategory)
        assertEquals(6, comparison.requiredShoes)
    }

    @Test
    fun mass_supplement_uses_exact_remaining_shoe_equivalent() {
        val result = BrakeCalculator.calculateMass(
            MassCalculationInput(3800.0, axleCount = 200, slopePermille = 12.0)
        )
        val supplement = BrakeCalculator.calculateMassSupplement(result, availableShoes = 15, axlesPerHandBrakeUnit = 4)
        assertEquals(15.2, result.shoesExact, 1e-9)
        assertEquals(0.2, supplement.remainingShoeEquivalent, 1e-9)
        assertEquals(0.5, supplement.additionalManualAxlesExact, 1e-9)
        assertEquals(1, supplement.additionalManualAxles)
    }

    @Test
    fun appendix_formula1_with_oil_and_wind() {
        val result = BrakeCalculator.calculateAppendix12(
            Appendix12Input(
                axleCount = 200,
                profileMode = ProfileMode.NORMAL,
                slopePermille = 8.0,
                formula = AppendixFormula.FORMULA_1,
                oilyRails = true,
                windSpeedMs = 16.0,
                windDirectionMatchesPossibleMovement = true,
                availableShoes = 16,
                axlesPerHandBrakeUnit = 4
            )
        )
        assertEquals(23, result.totalRequiredShoes)
        assertEquals(7, result.shoeShortage)
        assertEquals(35, result.substituteBrakeAxles)
        assertEquals(9, result.requiredHandBrakeUnits)
    }

    @Test
    fun appendix_slope_boundaries_keep_distinct_rules() {
        fun calculate(slope: Double) = BrakeCalculator.calculateAppendix12(
            Appendix12Input(
                axleCount = 200,
                profileMode = ProfileMode.NORMAL,
                slopePermille = slope,
                formula = if (slope <= 0.5) null else AppendixFormula.FORMULA_1,
                oilyRails = false,
                windSpeedMs = 0.0,
                windDirectionMatchesPossibleMovement = false,
                availableShoes = 0,
                axlesPerHandBrakeUnit = 4
            )
        )

        val below = calculate(0.499)
        val boundary = calculate(0.500)
        val above = calculate(0.501)
        val one = calculate(1.000)
        val aboveOne = calculate(1.001)

        assertTrue(below.isLowSlopeRule)
        assertTrue(below.usesLowSlopeSingleHandBrakeRule)
        assertTrue(boundary.isLowSlopeRule)
        assertEquals(false, boundary.usesLowSlopeSingleHandBrakeRule)
        assertEquals(1, above.oppositeSideShoes)
        assertEquals(1, one.oppositeSideShoes)
        assertEquals(0, aboveOne.oppositeSideShoes)
    }

    @Test
    fun appendix_horizontal_track_uses_one_parking_brake_unit() {
        val result = BrakeCalculator.calculateAppendix12(
            Appendix12Input(
                axleCount = 200,
                profileMode = ProfileMode.NORMAL,
                slopePermille = 0.0,
                formula = null,
                oilyRails = false,
                windSpeedMs = 0.0,
                windDirectionMatchesPossibleMovement = false,
                availableShoes = 0,
                axlesPerHandBrakeUnit = 4
            )
        )
        assertTrue(result.usesLowSlopeSingleHandBrakeRule)
        assertEquals(1, result.requiredHandBrakeUnits)
        assertEquals(0, result.substituteBrakeAxles)
        assertEquals(4, result.actuallyBrakedAxles)
    }

    @Test
    fun appendix_horizontal_special_rule_does_not_absorb_wind_shoes() {
        val result = BrakeCalculator.calculateAppendix12(
            Appendix12Input(
                axleCount = 200,
                profileMode = ProfileMode.NORMAL,
                slopePermille = 0.0,
                formula = null,
                oilyRails = false,
                windSpeedMs = 16.0,
                windDirectionMatchesPossibleMovement = true,
                availableShoes = 0,
                axlesPerHandBrakeUnit = 4
            )
        )
        assertTrue(result.usesLowSlopeSingleHandBrakeRule)
        assertEquals(3, result.windShoes)
        assertEquals(15, result.substituteBrakeAxles)
        assertEquals(5, result.requiredHandBrakeUnits)
        assertEquals(1, result.reserveBrakeAxles)
    }

    @Test
    fun appendix_wind_boundaries_and_non_200_axle_rounding() {
        fun calculate(wind: Double, axles: Int = 200) = BrakeCalculator.calculateAppendix12(
            Appendix12Input(
                axleCount = axles,
                profileMode = ProfileMode.NORMAL,
                slopePermille = 8.0,
                formula = AppendixFormula.FORMULA_1,
                oilyRails = false,
                windSpeedMs = wind,
                windDirectionMatchesPossibleMovement = true,
                availableShoes = 100,
                axlesPerHandBrakeUnit = 4
            )
        )

        assertEquals(0, calculate(15.0).windShoes)
        assertEquals(3, calculate(15.0001).windShoes)
        assertEquals(3, calculate(21.0).windShoes)
        assertEquals(7, calculate(21.0001).windShoes)
        assertEquals(4, calculate(16.0, axles = 201).windShoes)
        assertEquals(8, calculate(22.0, axles = 201).windShoes)
    }
}
