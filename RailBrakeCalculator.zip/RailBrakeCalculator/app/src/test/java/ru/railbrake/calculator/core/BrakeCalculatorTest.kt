package ru.railbrake.calculator.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BrakeCalculatorTest {
    @Test
    fun mass_4000t_212axles_12permille() {
        val result = BrakeCalculator.calculateMass(
            MassCalculationInput(
                massTons = 4000.0,
                axleCount = 212,
                slopePermille = 12.0
            )
        )
        assertTrue(result.heavyCategory)
        assertEquals(16, result.requiredShoes)
        assertEquals(40, result.fullManualBrakeAxles)
    }

    @Test
    fun mass_shortage_is_supplemented_not_replaced() {
        val result = BrakeCalculator.calculateMass(
            MassCalculationInput(4000.0, axleCount = 212, slopePermille = 12.0)
        )
        val supplement = BrakeCalculator.calculateMassSupplement(result, availableShoes = 10, axlesPerHandBrakeUnit = 4)
        assertEquals(6, supplement.shoeShortage)
        assertEquals(15, supplement.additionalManualAxles)
        assertEquals(4, supplement.requiredHandBrakeUnits)
        assertEquals(16, supplement.actuallyBrakedAxles)
        assertEquals(1, supplement.reserveManualAxles)
    }

    @Test
    fun consist_771t_34axles_10permille() {
        val result = BrakeCalculator.calculateMass(
            MassCalculationInput(771.0, axleCount = 34, slopePermille = 10.0)
        )
        assertEquals(3, result.requiredShoes)
        assertEquals(7, result.fullManualBrakeAxles)
    }

    @Test
    fun exactlyTen_requires_choice() {
        val error = runCatching {
            BrakeCalculator.calculateMass(
                MassCalculationInput(1000.0, axleCount = 100, slopePermille = 8.0)
            )
        }.exceptionOrNull()
        assertTrue(error != null)

        val light = BrakeCalculator.calculateMass(
            MassCalculationInput(1000.0, axleCount = 100, slopePermille = 8.0, tenTonsChoice = TenTonsChoice.LESS_THAN_10)
        )
        val heavy = BrakeCalculator.calculateMass(
            MassCalculationInput(1000.0, axleCount = 100, slopePermille = 8.0, tenTonsChoice = TenTonsChoice.TEN_OR_MORE)
        )
        assertEquals(6, light.requiredShoes)
        assertEquals(2, heavy.requiredShoes)
    }

    @Test
    fun appendix_formula1_with_oil_and_wind() {
        val result = BrakeCalculator.calculateAppendix12(
            Appendix12Input(
                axleCount = 200,
                profileMode = ProfileMode.NORMAL,
                slopePermille = 8.0,
                formula = AppendixFormula.FORMULA_1,
                oilyRails = true,
                windSpeedMs = 16.0,
                windDirectionMatchesPossibleMovement = true,
                availableShoes = 16,
                axlesPerHandBrakeUnit = 4
            )
        )
        assertEquals(23, result.totalRequiredShoes)
        assertEquals(7, result.shoeShortage)
        assertEquals(35, result.substituteBrakeAxles)
        assertEquals(9, result.requiredHandBrakeUnits)
    }
}
