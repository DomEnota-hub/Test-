package ru.railbrake.calculator.core

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max

enum class TenTonsChoice {
    LESS_THAN_10,
    TEN_OR_MORE
}

enum class AppendixFormula {
    FORMULA_1,
    FORMULA_2
}

enum class ProfileMode {
    NORMAL,
    BROKEN_FULL_TRACK,
    SEPARATE_SEGMENT
}

data class MassCalculationInput(
    val massTons: Double,
    val axleCount: Int? = null,
    val manualAxleLoadTons: Double? = null,
    val slopePermille: Double,
    val educationalTenTonsChoice: TenTonsChoice? = null
)

data class MassCalculationResult(
    val massTons: Double,
    val axleCount: Int?,
    val axleLoadTons: Double,
    val isExactlyTenTons: Boolean,
    val heavyCategory: Boolean,
    val slopePermille: Double,
    val shoeCoefficientPer100Tons: Double,
    val manualAxleCoefficientPer100Tons: Double,
    val shoesExact: Double,
    val requiredShoes: Int,
    val manualAxlesExact: Double,
    val fullManualBrakeAxles: Int
)

data class MassSupplementResult(
    val requiredShoes: Int,
    val availableShoes: Int,
    val shoeShortage: Int,
    val remainingShoeEquivalent: Double,
    val manualAxlesPerMissingShoe: Double,
    val additionalManualAxlesExact: Double,
    val additionalManualAxles: Int,
    val axlesPerHandBrakeUnit: Int,
    val requiredHandBrakeUnits: Int,
    val actuallyBrakedAxles: Int,
    val reserveManualAxles: Int
)

data class Appendix12Input(
    val axleCount: Int,
    val profileMode: ProfileMode,
    val slopePermille: Double,
    val formula: AppendixFormula?,
    val oilyRails: Boolean,
    val windSpeedMs: Double,
    val windDirectionMatchesPossibleMovement: Boolean,
    val availableShoes: Int,
    val axlesPerHandBrakeUnit: Int
)

data class Appendix12Result(
    val baseExactBeforeOil: Double,
    val baseExactAfterOil: Double,
    val baseShoes: Int,
    val oppositeSideShoes: Int,
    val windCoefficientPer200Axles: Int,
    val windShoes: Int,
    val totalRequiredShoes: Int,
    val availableShoes: Int,
    val shoeShortage: Int,
    val substituteBrakeAxles: Int,
    val axlesPerHandBrakeUnit: Int,
    val requiredHandBrakeUnits: Int,
    val actuallyBrakedAxles: Int,
    val reserveBrakeAxles: Int,
    val usesLowSlopeSingleHandBrakeRule: Boolean,
    val isLowSlopeRule: Boolean,
    val formulaUsed: AppendixFormula?
)

object BrakeCalculator {
    val massSlopesPermille = listOf(0.0, 2.0, 4.0, 6.0, 8.0, 10.0, 12.0)

    private val shoesHeavy = doubleArrayOf(0.2, 0.2, 0.2, 0.2, 0.2, 0.3, 0.4)
    private val shoesLight = doubleArrayOf(0.4, 0.4, 0.4, 0.4, 0.6, 0.8, 1.0)
    private val manualAxles = doubleArrayOf(0.4, 0.4, 0.4, 0.4, 0.6, 0.8, 1.0)

    fun wagonAxles(wagons4: Int, wagons6: Int, wagons8: Int, extraAxles: Int): Int {
        require(wagons4 >= 0 && wagons6 >= 0 && wagons8 >= 0 && extraAxles >= 0)
        return wagons4 * 4 + wagons6 * 6 + wagons8 * 8 + extraAxles
    }

    fun calculateMass(input: MassCalculationInput): MassCalculationResult {
        require(input.massTons > 0.0) { "Масса должна быть больше нуля" }

        val axleLoad = when {
            input.manualAxleLoadTons != null -> {
                require(input.manualAxleLoadTons > 0.0) { "Нагрузка на ось должна быть больше нуля" }
                input.manualAxleLoadTons
            }
            input.axleCount != null -> {
                require(input.axleCount > 0) { "Количество осей должно быть больше нуля" }
                input.massTons / input.axleCount
            }
            else -> error("Нужно указать количество осей или нагрузку на ось")
        }

        val slopeIndex = massSlopesPermille.indexOfFirst { abs(it - input.slopePermille) < 0.0001 }
        require(slopeIndex >= 0) { "Выберите уклон из таблицы: 0, 2, 4, 6, 8, 10 или 12‰" }

        val exactlyTen = abs(axleLoad - 10.0) < 1e-9
        val heavy = if (exactlyTen) {
            when (input.educationalTenTonsChoice) {
                TenTonsChoice.LESS_THAN_10 -> false
                TenTonsChoice.TEN_OR_MORE -> true
                null -> true
            }
        } else {
            axleLoad >= 10.0
        }

        val shoeCoefficient = if (heavy) shoesHeavy[slopeIndex] else shoesLight[slopeIndex]
        val manualCoefficient = manualAxles[slopeIndex]
        val shoesExact = input.massTons * shoeCoefficient / 100.0
        val manualExact = input.massTons * manualCoefficient / 100.0

        return MassCalculationResult(
            massTons = input.massTons,
            axleCount = input.axleCount,
            axleLoadTons = axleLoad,
            isExactlyTenTons = exactlyTen,
            heavyCategory = heavy,
            slopePermille = input.slopePermille,
            shoeCoefficientPer100Tons = shoeCoefficient,
            manualAxleCoefficientPer100Tons = manualCoefficient,
            shoesExact = shoesExact,
            requiredShoes = ceilToInt(shoesExact),
            manualAxlesExact = manualExact,
            fullManualBrakeAxles = ceilToInt(manualExact)
        )
    }

    fun calculateMassSupplement(
        massResult: MassCalculationResult,
        availableShoes: Int,
        axlesPerHandBrakeUnit: Int
    ): MassSupplementResult {
        require(availableShoes >= 0) { "Количество башмаков не может быть отрицательным" }
        require(axlesPerHandBrakeUnit > 0) { "Количество тормозных осей на единицу должно быть больше нуля" }

        val shortage = max(0, massResult.requiredShoes - availableShoes)
        val remainingEquivalent = max(0.0, massResult.shoesExact - availableShoes)
        val manualPerShoe = massResult.manualAxleCoefficientPer100Tons / massResult.shoeCoefficientPer100Tons
        val additionalExact = remainingEquivalent * manualPerShoe
        val additional = if (remainingEquivalent <= 0.0) 0 else ceilToInt(additionalExact)
        val units = if (additional == 0) 0 else ceilToInt(additional.toDouble() / axlesPerHandBrakeUnit)
        val actually = units * axlesPerHandBrakeUnit

        return MassSupplementResult(
            requiredShoes = massResult.requiredShoes,
            availableShoes = availableShoes,
            shoeShortage = shortage,
            remainingShoeEquivalent = remainingEquivalent,
            manualAxlesPerMissingShoe = manualPerShoe,
            additionalManualAxlesExact = additionalExact,
            additionalManualAxles = additional,
            axlesPerHandBrakeUnit = axlesPerHandBrakeUnit,
            requiredHandBrakeUnits = units,
            actuallyBrakedAxles = actually,
            reserveManualAxles = max(0, actually - additional)
        )
    }

    fun calculateAppendix12(input: Appendix12Input): Appendix12Result {
        require(input.axleCount > 0) { "Количество осей должно быть больше нуля" }
        require(input.slopePermille >= 0.0) { "Уклон не может быть отрицательным" }
        require(input.windSpeedMs >= 0.0) { "Скорость ветра не может быть отрицательной" }
        require(input.availableShoes >= 0) { "Количество башмаков не может быть отрицательным" }
        require(input.axlesPerHandBrakeUnit > 0) { "Количество тормозных осей на единицу должно быть больше нуля" }

        val lowSlopeRule = input.slopePermille <= 0.5
        val baseBeforeOil: Double
        val formulaUsed: AppendixFormula?
        var oppositeShoes = 0

        if (lowSlopeRule) {
            baseBeforeOil = 2.0
            formulaUsed = null
        } else {
            val formula = requireNotNull(input.formula) { "Для уклона более 0,5‰ выберите формулу" }
            formulaUsed = formula
            baseBeforeOil = when (formula) {
                AppendixFormula.FORMULA_1 -> input.axleCount * (1.5 * input.slopePermille + 1.0) / 200.0
                AppendixFormula.FORMULA_2 -> input.axleCount * (4.0 * input.slopePermille + 1.0) / 200.0
            }
            if (input.slopePermille <= 1.0) oppositeShoes = 1
        }

        val baseAfterOil = if (input.oilyRails) baseBeforeOil * 1.5 else baseBeforeOil
        val baseShoes = ceilToInt(baseAfterOil)

        val windCoefficient = when {
            !input.windDirectionMatchesPossibleMovement -> 0
            input.windSpeedMs > 21.0 -> 7
            input.windSpeedMs > 15.0 -> 3
            else -> 0
        }
        val windShoes = if (windCoefficient == 0) 0 else ceilToInt(input.axleCount * windCoefficient / 200.0)
        val total = baseShoes + oppositeShoes + windShoes
        val shortage = max(0, total - input.availableShoes)

        val usesLowSlopeSingleHandBrakeRule =
            input.slopePermille < 0.5 && shortage > 0 && input.availableShoes < baseShoes
        val standardShoeShortage = if (usesLowSlopeSingleHandBrakeRule) {
            max(0, windShoes - input.availableShoes)
        } else {
            shortage
        }
        val substituteAxles = standardShoeShortage * 5
        val standardUnits = if (substituteAxles == 0) {
            0
        } else {
            ceilToInt(substituteAxles.toDouble() / input.axlesPerHandBrakeUnit)
        }
        val units = standardUnits + if (usesLowSlopeSingleHandBrakeRule) 1 else 0
        val actually = units * input.axlesPerHandBrakeUnit

        return Appendix12Result(
            baseExactBeforeOil = baseBeforeOil,
            baseExactAfterOil = baseAfterOil,
            baseShoes = baseShoes,
            oppositeSideShoes = oppositeShoes,
            windCoefficientPer200Axles = windCoefficient,
            windShoes = windShoes,
            totalRequiredShoes = total,
            availableShoes = input.availableShoes,
            shoeShortage = shortage,
            substituteBrakeAxles = substituteAxles,
            axlesPerHandBrakeUnit = input.axlesPerHandBrakeUnit,
            requiredHandBrakeUnits = units,
            actuallyBrakedAxles = actually,
            reserveBrakeAxles = max(0, standardUnits * input.axlesPerHandBrakeUnit - substituteAxles),
            usesLowSlopeSingleHandBrakeRule = usesLowSlopeSingleHandBrakeRule,
            isLowSlopeRule = lowSlopeRule,
            formulaUsed = formulaUsed
        )
    }

    private fun ceilToInt(value: Double): Int = ceil(value - 1e-12).toInt()
}
