package ru.railbrake.calculator.data

import android.content.Context

class FavoriteArticleRepository(context: Context) {
    private val prefs = context.getSharedPreferences("favorite_articles", Context.MODE_PRIVATE)

    fun load(): Set<String> = prefs.getStringSet(KEY, emptySet()).orEmpty().toSet()

    fun toggle(articleId: String): Set<String> {
        val updated = load().toMutableSet().apply {
            if (!add(articleId)) remove(articleId)
        }
        prefs.edit().putStringSet(KEY, updated).apply()
        return updated
    }

    private companion object {
        const val KEY = "article_ids"
    }
}
