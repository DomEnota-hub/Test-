package ru.railbrake.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import ru.railbrake.calculator.ui.BrakeCalculatorApp
import ru.railbrake.calculator.ui.theme.RailBrakeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RailBrakeTheme {
                BrakeCalculatorApp()
            }
        }
    }
}
