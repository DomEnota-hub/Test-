package ru.railbrake.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import ru.railbrake.calculator.ui.BrakeCalculatorApp
import ru.railbrake.calculator.ui.theme.AccentPalette
import ru.railbrake.calculator.ui.theme.RailBrakeTheme

// Разработчик: Кузнецов Д.С. (DomEnota)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val preferences = getSharedPreferences("appearance", MODE_PRIVATE)
            var paletteName by rememberSaveable {
                mutableStateOf(preferences.getString("accent_palette", AccentPalette.BLUE.name) ?: AccentPalette.BLUE.name)
            }
            val palette = runCatching { AccentPalette.valueOf(paletteName) }.getOrDefault(AccentPalette.BLUE)
            RailBrakeTheme(palette) {
                BrakeCalculatorApp(
                    palette = palette,
                    onPaletteChange = {
                        paletteName = it.name
                        preferences.edit().putString("accent_palette", it.name).apply()
                    }
                )
            }
        }
    }
}
