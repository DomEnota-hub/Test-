package ru.railbrake.calculator.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ru.railbrake.calculator.R
import ru.railbrake.calculator.core.DiagramHotspot
import ru.railbrake.calculator.core.KnowledgeArticle
import ru.railbrake.calculator.core.KnowledgeRepository

@Composable
fun KnowledgeBaseScreen() {
    var selectedArticleId by rememberSaveable { mutableStateOf<String?>(null) }
    val article = selectedArticleId?.let { id -> KnowledgeRepository.articles.firstOrNull { it.id == id } }

    if (article == null) {
        KnowledgeHome(onOpenArticle = { selectedArticleId = it.id })
    } else {
        KnowledgeArticleScreen(article = article, onBack = { selectedArticleId = null })
    }
}

@Composable
private fun KnowledgeHome(onOpenArticle: (KnowledgeArticle) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("Все") }
    val results = remember(query, category) { KnowledgeRepository.search(query, category) }

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Карманная железнодорожная база", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            "Материалы хранятся в приложении и доступны офлайн. Для открытия внешних ссылок на первоисточники требуется интернет.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Поиск по справочнику") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp)
        )

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(KnowledgeRepository.categories) { item ->
                FilterChip(
                    selected = category == item,
                    onClick = { category = item },
                    label = { Text(item) }
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(results, key = { it.id }) { item ->
                Card(
                    onClick = { onOpenArticle(item) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(item.category, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("• ${item.status}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(item.summary, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (item.hasInteractiveDiagram) {
                            Text("Интерактивная схема →", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
            if (results.isEmpty()) {
                item {
                    Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                        Text("Ничего не найдено. Попробуйте другой запрос.", modifier = Modifier.padding(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun KnowledgeArticleScreen(article: KnowledgeArticle, onBack: () -> Unit) {
    val context = LocalContext.current
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            TextButton(onClick = onBack) { Text("← К справочнику") }
        }
        item {
            Text(article.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(4.dp))
            Text("${article.category} • ${article.status}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        }
        item {
            ArticleCard {
                Text(article.summary, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            }
        }
        items(article.body) { paragraph ->
            Text(paragraph, style = MaterialTheme.typography.bodyLarge)
        }
        if (article.hasInteractiveDiagram) {
            item { Vl80InteractiveDiagram() }
        }
        item {
            ArticleCard {
                Text("Источник", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(article.source.title, style = MaterialTheme.typography.bodyMedium)
                article.source.note?.let {
                    Spacer(Modifier.height(5.dp))
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                article.source.externalUrl?.let { url ->
                    Spacer(Modifier.height(10.dp))
                    Text("Для открытия внешнего источника требуется интернет.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = {
                        try {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        } catch (_: ActivityNotFoundException) {
                            Toast.makeText(context, "Не найдено приложение для открытия ссылки", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Text("Открыть первоисточник ↗")
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun ArticleCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
    ) {
        Column(Modifier.padding(16.dp)) { content() }
    }
}

@Composable
private fun Vl80InteractiveDiagram() {
    var selected by remember { mutableStateOf<DiagramHotspot?>(null) }
    var showZones by rememberSaveable { mutableStateOf(true) }
    val horizontal = rememberScrollState()

    ArticleCard {
        Text("Интерактивная схема ВЛ80С", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            "Схема крупная и прокручивается по горизонтали. Нажмите на подсвеченную область.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Показывать зоны", modifier = Modifier.weight(1f))
            Switch(checked = showZones, onCheckedChange = { showZones = it })
        }
        Spacer(Modifier.height(8.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(horizontal)
                .background(Color.White, RoundedCornerShape(12.dp))
        ) {
            Box(
                modifier = Modifier
                    .width(1050.dp)
                    .aspectRatio(1667f / 626f)
            ) {
                androidx.compose.foundation.Image(
                    painter = painterResource(R.drawable.vl80s_layout_section1),
                    contentDescription = "Расположение оборудования ВЛ80С, секция 1",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.FillBounds
                )
                Canvas(
                    modifier = Modifier
                        .matchParentSize()
                        .pointerInput(Unit) {
                            detectTapGestures { offset ->
                                val nx = offset.x / size.width.toFloat()
                                val ny = offset.y / size.height.toFloat()
                                selected = KnowledgeRepository.vl80LayoutHotspots.lastOrNull { it.contains(nx, ny) }
                            }
                        }
                ) {
                    if (showZones) {
                        KnowledgeRepository.vl80LayoutHotspots.forEach { spot ->
                            val x = spot.left * size.width
                            val y = spot.top * size.height
                            val w = (spot.right - spot.left) * size.width
                            val h = (spot.bottom - spot.top) * size.height
                            drawRect(
                                color = Color(0x286EA8FE),
                                topLeft = Offset(x, y),
                                size = Size(w, h)
                            )
                            drawRect(
                                color = Color(0xCC2962C7),
                                topLeft = Offset(x, y),
                                size = Size(w, h),
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Активные зоны прототипа: БСА №1/2, тяговый трансформатор, ВВК1/2, МВ3/4, МК и БУРТ.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    selected?.let { spot ->
        AlertDialog(
            onDismissRequest = { selected = null },
            confirmButton = { Button(onClick = { selected = null }) { Text("Понятно") } },
            title = { Text(spot.title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(spot.subtitle, fontWeight = FontWeight.Bold)
                    Text(spot.details)
                }
            }
        )
    }
}
