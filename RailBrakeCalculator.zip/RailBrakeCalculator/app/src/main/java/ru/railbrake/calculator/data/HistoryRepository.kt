package ru.railbrake.calculator.data

import android.content.Context
import android.util.Base64

data class HistoryRecord(
    val timestampMillis: Long,
    val mode: String,
    val title: String,
    val summary: String,
    val details: String
)

class HistoryRepository(context: Context) {
    private val prefs = context.getSharedPreferences("calculation_history", Context.MODE_PRIVATE)

    fun load(): List<HistoryRecord> = prefs.getStringSet(KEY, emptySet())
        .orEmpty()
        .mapNotNull(::decode)
        .sortedByDescending { it.timestampMillis }

    fun add(record: HistoryRecord) {
        val current = load().toMutableList()
        current.add(0, record)
        val trimmed = current.distinctBy { it.timestampMillis }.take(MAX)
        prefs.edit().putStringSet(KEY, trimmed.map(::encode).toSet()).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY).apply()
    }

    private fun encode(record: HistoryRecord): String = listOf(
        record.timestampMillis.toString(),
        b64(record.mode),
        b64(record.title),
        b64(record.summary),
        b64(record.details)
    ).joinToString("|")

    private fun decode(raw: String): HistoryRecord? {
        val p = raw.split('|')
        if (p.size != 5) return null
        return runCatching {
            HistoryRecord(
                timestampMillis = p[0].toLong(),
                mode = unb64(p[1]),
                title = unb64(p[2]),
                summary = unb64(p[3]),
                details = unb64(p[4])
            )
        }.getOrNull()
    }

    private fun b64(value: String): String = Base64.encodeToString(
        value.toByteArray(Charsets.UTF_8),
        Base64.NO_WRAP or Base64.URL_SAFE
    )

    private fun unb64(value: String): String = String(
        Base64.decode(value, Base64.NO_WRAP or Base64.URL_SAFE),
        Charsets.UTF_8
    )

    companion object {
        private const val KEY = "records"
        private const val MAX = 30
    }
}
