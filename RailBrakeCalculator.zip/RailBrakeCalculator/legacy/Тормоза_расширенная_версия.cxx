#include <iostream>
#include <iomanip>
#include <cmath>
#include <limits>
#include <string>
#include <vector>
#include <sstream>

using namespace std;


// ======================================================
// ОБЩИЕ СЛУЖЕБНЫЕ ФУНКЦИИ
// ======================================================

int ceilInt(double x)
{
    return static_cast<int>(ceil(x - 1e-12));
}


int readInt(const string& prompt, int minValue)
{
    int x;

    while (true)
    {
        cout << prompt;

        if (cin >> x && x >= minValue)
            return x;

        cout << "Некорректный ввод. Повторите.\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}


double readDouble(
    const string& prompt,
    double minValue,
    bool allowEqual = true
)
{
    double x;

    while (true)
    {
        cout << prompt;

        if (
            cin >> x &&
            (allowEqual ? x >= minValue : x > minValue)
        )
        {
            return x;
        }

        cout << "Некорректный ввод. Повторите.\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}


bool readYesNo(const string& prompt)
{
    string answer;

    while (true)
    {
        cout << prompt;
        cin >> answer;

        if (
            answer == "y" || answer == "Y" ||
            answer == "д" || answer == "Д"
        )
        {
            return true;
        }

        if (
            answer == "n" || answer == "N" ||
            answer == "н" || answer == "Н"
        )
        {
            return false;
        }

        cout << "Введите y/n (или д/н).\n";
    }
}


int readChoice(
    const string& prompt,
    int minValue,
    int maxValue
)
{
    while (true)
    {
        int choice = readInt(prompt, minValue);

        if (choice <= maxValue)
            return choice;

        cout
            << "Допустимое значение: от "
            << minValue
            << " до "
            << maxValue
            << ".\n";
    }
}


int chooseMassSlope()
{
    cout << "\nВыберите уклон:\n";
    cout << "1 - 0 промилле\n";
    cout << "2 - 2 промилле  (0.002)\n";
    cout << "3 - 4 промилле  (0.004)\n";
    cout << "4 - 6 промилле  (0.006)\n";
    cout << "5 - 8 промилле  (0.008)\n";
    cout << "6 - 10 промилле (0.010)\n";
    cout << "7 - 12 промилле (0.012)\n";

    return readChoice("Ваш выбор: ", 1, 7) - 1;
}


// Предварительное объявление режима ИДП
void modeAppendix12(
    int prefilledAxles,
    bool hasPrefilledConditions,
    bool prefilledOily,
    double prefilledWind,
    bool prefilledWindCoincides
);


// ======================================================
// БАЗА ЛОКОМОТИВОВ ДЛЯ СПЛОТОК
// ======================================================

struct LocomotiveSpec
{
    string name;
    string type;
    double mass;
    int axles;
    string note;
};


const vector<LocomotiveSpec> LOCOMOTIVE_DB =
{
    // Электровозы постоянного тока
    {"ВЛ8",       "электровоз постоянного тока", 180.0, 8,  "типовая служебная масса"},
    {"ВЛ10",      "электровоз постоянного тока", 184.0, 8,  "типовая служебная масса"},
    {"ВЛ10У",     "электровоз постоянного тока", 200.0, 8,  "утяжеленный"},
    {"ВЛ11",      "электровоз постоянного тока", 184.0, 8,  "двухсекционный вариант"},
    {"ВЛ11, 3 секции", "электровоз постоянного тока", 276.0, 12, "трехсекционный вариант"},
    {"ЧС7",       "пассажирский электровоз постоянного тока", 172.0, 8, "двухсекционный"},
    {"ЭП2К",      "пассажирский электровоз постоянного тока", 135.0, 6, ""},
    {"2ЭС4К",     "грузовой электровоз постоянного тока", 192.0, 8, ""},
    {"2ЭС6",      "грузовой электровоз постоянного тока", 200.0, 8, ""},
    {"3ЭС6",      "грузовой электровоз постоянного тока", 300.0, 12, ""},
    {"2ЭС10",     "грузовой электровоз постоянного тока", 200.0, 8, ""},
    {"3ЭС10",     "грузовой электровоз постоянного тока", 300.0, 12, ""},

    // Электровозы переменного тока
    {"ВЛ60К",     "электровоз переменного тока", 138.0, 6, ""},
    {"ВЛ80К",     "грузовой электровоз переменного тока", 184.0, 8, "учебная база ВУ-45"},
    {"ВЛ80Т",     "грузовой электровоз переменного тока", 192.0, 8, "учебная база ВУ-45"},
    {"ВЛ80С",     "грузовой электровоз переменного тока", 192.0, 8, "учебная база ВУ-45"},
    {"ВЛ80С, 3 секции", "грузовой электровоз переменного тока", 288.0, 12, "три секции по 4 оси"},
    {"ВЛ85",      "грузовой электровоз переменного тока", 288.0, 12, "для серийных машин встречаются варианты массы; при сомнении ввести вручную"},
    {"ВЛ65",      "электровоз переменного тока", 132.0, 6, ""},
    {"ЭП1",       "пассажирский электровоз переменного тока", 132.0, 6, ""},
    {"ЭП1М",      "пассажирский электровоз переменного тока", 135.0, 6, "масса принята по учебному файлу ВУ-45"},
    {"ЭП1П",      "пассажирский электровоз переменного тока", 132.0, 6, ""},
    {"ЧС4Т",      "пассажирский электровоз переменного тока", 126.0, 6, ""},
    {"ЧС8",       "пассажирский электровоз переменного тока", 172.0, 8, "двухсекционный"},
    {"2ЭС5К",     "грузовой электровоз переменного тока", 200.0, 8, "Ермак"},
    {"3ЭС5К",     "грузовой электровоз переменного тока", 300.0, 12, "Ермак"},
    {"4ЭС5К",     "грузовой электровоз переменного тока", 400.0, 16, "Ермак"},
    {"2ЭС7",      "грузовой электровоз переменного тока", 200.0, 8, ""},

    // Двухсистемные
    {"ВЛ82",      "двухсистемный электровоз", 188.0, 8, "ранний вариант; масса зависит от исполнения"},
    {"ВЛ82М",     "двухсистемный электровоз", 200.0, 8, ""},

    // Магистральные тепловозы
    {"М62",       "магистральный тепловоз", 116.5, 6, ""},
    {"2М62",      "магистральный тепловоз", 240.0, 12, "две секции по 120 т"},
    {"2М62У",     "магистральный тепловоз", 252.0, 12, "две секции по 126 т"},
    {"2ТЭ10М",    "магистральный грузовой тепловоз", 276.0, 12, ""},
    {"3ТЭ10М",    "магистральный грузовой тепловоз", 414.0, 18, ""},
    {"2ТЭ116",    "магистральный грузовой тепловоз", 276.0, 12, "учебная база ВУ-45"},
    {"ТЭП70",     "пассажирский тепловоз", 132.0, 6, "учебная база ВУ-45"},
    {"ТЭП70БС",   "пассажирский тепловоз", 135.0, 6, ""},
    {"2ТЭ25КМ",   "магистральный грузовой тепловоз", 288.0, 12, "две секции по 144 т"},
    {"3ТЭ25К2М",  "магистральный грузовой тепловоз", 441.0, 18, "три секции по 147 т"},
    {"2ТЭ28",     "магистральный грузовой тепловоз", 294.0, 12, "две секции"},
    {"3ТЭ28",     "магистральный грузовой тепловоз", 441.0, 18, "три секции"},

    // Маневровые и маневрово-вывозные тепловозы
    {"ТЭМ2",      "маневровый тепловоз", 126.0, 6, "у серии встречаются исполнения 120-126 т"},
    {"ТЭМ7А",     "маневрово-вывозной тепловоз", 180.0, 8, "учебная база ВУ-45"},
    {"ТЭМ18ДМ",   "маневровый тепловоз", 126.0, 6, ""},
    {"ЧМЭ3",      "маневровый тепловоз", 123.0, 6, "учебная база ВУ-45"}
};


void printLocomotiveDatabase()
{
    cout << "\n================ БАЗА ЛОКОМОТИВОВ ================\n";

    for (size_t i = 0; i < LOCOMOTIVE_DB.size(); ++i)
    {
        const auto& loco = LOCOMOTIVE_DB[i];

        cout
            << setw(2) << (i + 1)
            << " - " << left << setw(18) << loco.name
            << right
            << " | " << setw(6) << fixed << setprecision(1) << loco.mass << " т"
            << " | " << setw(2) << loco.axles << " ос."
            << " | " << loco.type;

        if (!loco.note.empty())
            cout << " | " << loco.note;

        cout << "\n";
    }

    cout
        << (LOCOMOTIVE_DB.size() + 1)
        << " - Другой локомотив: ввести массу и оси вручную\n";

    cout << "0 - Закончить набор сплотки\n";
}


struct MassInputData
{
    double mass = 0.0;
    int axles = 0;
    double axleLoad = 0.0;
    string source;
};


MassInputData inputLocomotiveConsist()
{
    MassInputData data;
    data.source = "сплотка локомотивов";

    cout
        << "\nСПЛОТКА ЛОКОМОТИВОВ\n"
        << "Добавляйте только те локомотивы, которые должны войти в расчет.\n"
        << "Ведущий локомотив не добавляйте, если по условию он не учитывается.\n";

    while (true)
    {
        printLocomotiveDatabase();

        int choice = readChoice(
            "Выберите локомотив: ",
            0,
            static_cast<int>(LOCOMOTIVE_DB.size()) + 1
        );

        if (choice == 0)
        {
            if (data.axles == 0)
            {
                cout << "Сплотка пока пустая. Добавьте хотя бы один локомотив.\n";
                continue;
            }

            break;
        }

        int quantity = readInt("Количество таких локомотивов: ", 1);

        if (choice == static_cast<int>(LOCOMOTIVE_DB.size()) + 1)
        {
            double customMass = readDouble(
                "Масса одного локомотива, т: ",
                0.0,
                false
            );

            int customAxles = readInt(
                "Количество осей одного локомотива: ",
                1
            );

            data.mass += customMass * quantity;
            data.axles += customAxles * quantity;

            cout
                << "Добавлено: " << quantity
                << " шт., масса " << customMass * quantity
                << " т, осей " << customAxles * quantity
                << ".\n";
        }
        else
        {
            const auto& loco = LOCOMOTIVE_DB[choice - 1];

            data.mass += loco.mass * quantity;
            data.axles += loco.axles * quantity;

            cout
                << "Добавлено: " << loco.name
                << " x " << quantity
                << " = " << loco.mass * quantity << " т, "
                << loco.axles * quantity << " осей.\n";
        }

        cout
            << "Текущий итог сплотки: "
            << data.mass << " т, "
            << data.axles << " осей.\n";
    }

    data.axleLoad = data.mass / data.axles;
    return data;
}


MassInputData inputMassData()
{
    MassInputData data;

    cout << "\nКак задать исходные данные?\n";
    cout << "1 - готовые масса и количество осей\n";
    cout << "2 - масса + автоматически посчитать оси по вагонам\n";
    cout << "3 - сплотка локомотивов из встроенной базы\n";
    cout << "4 - масса + фактическая нагрузка на ось вручную\n";

    int mode = readChoice("Ваш выбор: ", 1, 4);

    if (mode == 3)
        return inputLocomotiveConsist();

    data.mass = readDouble("Масса учитываемого состава, т: ", 0.0, false);

    if (mode == 1)
    {
        data.axles = readInt("Количество учитываемых осей: ", 1);
        data.axleLoad = data.mass / data.axles;
        data.source = "готовая масса и оси";
    }
    else if (mode == 2)
    {
        cout << "\nВведите количество вагонов по осности.\n";
        int wag4 = readInt("4-осных вагонов: ", 0);
        int wag6 = readInt("6-осных вагонов: ", 0);
        int wag8 = readInt("8-осных вагонов: ", 0);
        int extraAxles = readInt(
            "Дополнительных осей от прочих вагонов (иначе 0): ",
            0
        );

        data.axles = 4 * wag4 + 6 * wag6 + 8 * wag8 + extraAxles;

        if (data.axles <= 0)
        {
            cout
                << "Количество осей получилось 0. "
                << "Введите готовое количество осей.\n";
            data.axles = readInt("Количество осей: ", 1);
        }

        data.axleLoad = data.mass / data.axles;
        data.source = "оси рассчитаны по вагонам";
    }
    else
    {
        data.axleLoad = readDouble(
            "Фактическая нагрузка на ось, т/ось: ",
            0.0,
            false
        );

        data.axles = 0;
        data.source = "нагрузка на ось введена вручную";
    }

    return data;
}


bool chooseHeavyCategory(double axleLoad)
{
    // Если расчет попал ровно на границу 10 т/ось,
    // пользователь сам выбирает, какую строку таблицы применить.
    if (fabs(axleLoad - 10.0) < 1e-9)
    {
        cout
            << "\nНагрузка получилась ровно 10.00 т/ось.\n"
            << "Для учебного расчета выберите категорию вручную:\n"
            << "1 - рассчитать по строке МЕНЕЕ 10 т/ось\n"
            << "2 - рассчитать по строке 10 т/ось И БОЛЕЕ\n";

        return readChoice("Ваш выбор: ", 1, 2) == 2;
    }

    return axleLoad >= 10.0;
}


struct MassResult
{
    double mass = 0.0;
    int axles = 0;
    double axleLoad = 0.0;
    int slopeIndex = 0;
    double slope = 0.0;
    bool heavy = false;
    double shoeCoefficient = 0.0;
    double manualAxleCoefficient = 0.0;
    double shoesExact = 0.0;
    int shoesWhole = 0;
    double manualAxlesExact = 0.0;
    int manualAxlesWhole = 0;
};


MassResult calculateMassResult(
    const MassInputData& input,
    int slopeIndex,
    bool heavy
)
{
    static const double slopes[] = {0, 2, 4, 6, 8, 10, 12};
    static const double shoesHeavy[] = {0.2, 0.2, 0.2, 0.2, 0.2, 0.3, 0.4};
    static const double shoesLight[] = {0.4, 0.4, 0.4, 0.4, 0.6, 0.8, 1.0};
    static const double manualAxles[] = {0.4, 0.4, 0.4, 0.4, 0.6, 0.8, 1.0};

    MassResult result;
    result.mass = input.mass;
    result.axles = input.axles;
    result.axleLoad = input.axleLoad;
    result.slopeIndex = slopeIndex;
    result.slope = slopes[slopeIndex];
    result.heavy = heavy;
    result.shoeCoefficient = heavy ? shoesHeavy[slopeIndex] : shoesLight[slopeIndex];
    result.manualAxleCoefficient = manualAxles[slopeIndex];
    result.shoesExact = result.mass * result.shoeCoefficient / 100.0;
    result.shoesWhole = ceilInt(result.shoesExact);
    result.manualAxlesExact = result.mass * result.manualAxleCoefficient / 100.0;
    result.manualAxlesWhole = ceilInt(result.manualAxlesExact);
    return result;
}


struct CalculationRecord
{
    string source;
    double mass = 0.0;
    int axles = 0;
    double axleLoad = 0.0;
    double slope = 0.0;
    int shoes = 0;
    int manualAxles = 0;
    int availableShoes = 0;
};


vector<CalculationRecord> HISTORY;


void addHistory(
    const string& source,
    const MassResult& result,
    int availableShoes
)
{
    HISTORY.push_back({
        source,
        result.mass,
        result.axles,
        result.axleLoad,
        result.slope,
        result.shoesWhole,
        result.manualAxlesWhole,
        availableShoes
    });

    const size_t MAX_HISTORY = 20;
    if (HISTORY.size() > MAX_HISTORY)
        HISTORY.erase(HISTORY.begin());
}


void showHistory()
{
    cout << "\n=============================================\n";
    cout << "           ИСТОРИЯ РАСЧЕТОВ ПО МАССЕ\n";
    cout << "=============================================\n";

    if (HISTORY.empty())
    {
        cout << "История пока пуста.\n";
        return;
    }

    for (size_t i = 0; i < HISTORY.size(); ++i)
    {
        const auto& h = HISTORY[i];

        cout
            << (i + 1) << ". "
            << h.mass << " т";

        if (h.axles > 0)
            cout << " / " << h.axles << " осей";

        cout
            << " / " << fixed << setprecision(2) << h.axleLoad << " т/ось"
            << " / " << h.slope << " промилле"
            << " -> " << h.shoes << " ТБ, "
            << h.manualAxles << " ручн. торм. осей"
            << " / доступно ТБ: " << h.availableShoes
            << " / " << h.source
            << "\n";
    }
}


void printMassTrainingExplanation(const MassResult& r)
{
    cout << "\n---------------------------------------------\n";
    cout << "УЧЕБНОЕ ОБЪЯСНЕНИЕ\n";
    cout << "---------------------------------------------\n";

    if (r.axles > 0)
    {
        cout
            << "1. Средняя нагрузка на ось:\n"
            << "   q = M / n = "
            << r.mass << " / " << r.axles
            << " = " << r.axleLoad << " т/ось\n";
    }
    else
    {
        cout
            << "1. Нагрузка на ось введена вручную: "
            << r.axleLoad << " т/ось\n";
    }

    cout
        << "2. Применена категория: "
        << (r.heavy ? "10 т/ось и более" : "менее 10 т/ось")
        << ".\n";

    cout
        << "3. Коэффициент башмаков при уклоне "
        << r.slope << " промилле: "
        << r.shoeCoefficient << " на 100 т.\n";

    cout
        << "4. Башмаки:\n"
        << "   K = M * k / 100 = "
        << r.mass << " * " << r.shoeCoefficient
        << " / 100 = " << r.shoesExact
        << " -> " << r.shoesWhole << " шт.\n";

    cout
        << "5. Ручные тормозные оси:\n"
        << "   N = M * kруч / 100 = "
        << r.mass << " * " << r.manualAxleCoefficient
        << " / 100 = " << r.manualAxlesExact
        << " -> " << r.manualAxlesWhole << " осей.\n";
}


void processAvailableShoes(
    const MassResult& r,
    int availableShoes,
    bool trainingMode
)
{
    cout << "\n=============================================\n";
    cout << "                  РЕЗУЛЬТАТ\n";
    cout << "=============================================\n";

    cout << fixed << setprecision(2);
    cout << "Масса: " << r.mass << " т\n";

    if (r.axles > 0)
        cout << "Количество осей: " << r.axles << "\n";

    cout << "Нагрузка на ось: " << r.axleLoad << " т/ось\n";
    cout << "Уклон: " << r.slope << " промилле\n";
    cout << "Требуется башмаков: " << r.shoesWhole << " шт.\n";
    cout << "Полная норма ручных тормозных осей: " << r.manualAxlesWhole << " осей\n";
    cout << "Доступно башмаков: " << availableShoes << " шт.\n";

    if (trainingMode)
        printMassTrainingExplanation(r);

    if (availableShoes >= r.shoesWhole)
    {
        cout << "\nТормозных башмаков достаточно.\n";
        cout << "Запас: " << availableShoes - r.shoesWhole << " шт.\n";
        return;
    }

    int missingShoes = r.shoesWhole - availableShoes;
    double manualAxlesPerShoe = r.manualAxleCoefficient / r.shoeCoefficient;
    double additionalManualAxlesExact = missingShoes * manualAxlesPerShoe;
    int additionalManualAxles = ceilInt(additionalManualAxlesExact);

    cout << "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n";
    cout << "       ТОРМОЗНЫХ БАШМАКОВ НЕДОСТАТОЧНО\n";
    cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n";
    cout << "Не хватает: " << missingShoes << " башмак(ов).\n";
    cout << "Имеющиеся " << availableShoes << " башмак(ов) продолжают использоваться.\n";
    cout << "Ручной тормоз дополняет только недостающую часть.\n";

    if (trainingMode)
    {
        cout
            << "\nРасчет дополнения:\n"
            << "ручных осей на 1 башмак = "
            << r.manualAxleCoefficient << " / "
            << r.shoeCoefficient << " = "
            << manualAxlesPerShoe << "\n"
            << "дополнительные ручные оси = "
            << missingShoes << " * "
            << manualAxlesPerShoe << " = "
            << additionalManualAxlesExact << "\n";
    }

    cout
        << "Для компенсации дефицита требуется не менее "
        << additionalManualAxles
        << " ручных тормозных осей.\n";

    int axlesPerHandBrake = readInt(
        "На сколько осей действует ручной тормоз одного вагона/единицы? ",
        1
    );

    int neededUnits = ceilInt(
        static_cast<double>(additionalManualAxles) / axlesPerHandBrake
    );

    int actuallyBrakedAxles = neededUnits * axlesPerHandBrake;
    int reserveAxles = actuallyBrakedAxles - additionalManualAxles;

    cout
        << "Необходимо включить ручные тормоза минимум на "
        << neededUnits << " единиц(ах).\n";

    cout
        << "Фактически будет заторможено: "
        << actuallyBrakedAxles << " осей.\n";

    cout
        << "Запас по ручным тормозным осям: "
        << reserveAxles << " ос.\n";

    cout << "\nИТОГО:\n";
    cout
        << availableShoes
        << " тормозных башмаков + "
        << neededUnits
        << " единиц(а/ы) с ручным тормозом.\n";
}


// ======================================================
// РЕЖИМ 1
// РАСЧЕТ ПО МАССЕ
// ======================================================

void modeMass()
{
    cout << "\n=============================================\n";
    cout << "              РАСЧЕТ ПО МАССЕ\n";
    cout << "=============================================\n";

    cout << "Режим вывода:\n";
    cout << "1 - быстрый\n";
    cout << "2 - учебный: показывать формулы и логику\n";
    bool trainingMode = readChoice("Ваш выбор: ", 1, 2) == 2;

    MassInputData input = inputMassData();

    int slopeIndex = chooseMassSlope();
    bool heavy = chooseHeavyCategory(input.axleLoad);
    MassResult result = calculateMassResult(input, slopeIndex, heavy);

    while (true)
    {
        cout << fixed << setprecision(2);
        cout << "\n---------------------------------------------\n";
        cout << "ПОТРЕБНОЕ КОЛИЧЕСТВО\n";
        cout << "---------------------------------------------\n";
        cout << "Требуется тормозных башмаков: " << result.shoesWhole << " шт.\n";
        cout << "Требуется ручных тормозных осей: " << result.manualAxlesWhole << " осей.\n";

        int availableShoes = readInt(
            "Количество доступных тормозных башмаков: ",
            0
        );

        processAvailableShoes(result, availableShoes, trainingMode);
        addHistory(input.source, result, availableShoes);

        cout << "\nЧто изменить в этом же расчете?\n";
        cout << "1 - ничего, продолжить\n";
        cout << "2 - изменить только количество доступных башмаков\n";
        cout << "3 - изменить только уклон\n";

        int repeatChoice = readChoice("Ваш выбор: ", 1, 3);

        if (repeatChoice == 2)
            continue;

        if (repeatChoice == 3)
        {
            slopeIndex = chooseMassSlope();
            result = calculateMassResult(input, slopeIndex, heavy);
            continue;
        }

        break;
    }

    cout << "\n=============================================\n";
    cout << "РАСЧЕТ ВЫПОЛНЕН ПО МАССЕ\n";
    cout << "=============================================\n";

    if (!readYesNo(
        "\nДополнительно проверить условия станционного закрепления? (y/n): "
    ))
    {
        return;
    }

    bool oily = readYesNo("Замасленные рельсы? (y/n): ");

    double wind = readDouble(
        "Скорость ветра, м/с (0 если не учитывать): ",
        0.0,
        true
    );

    bool windCoincides = false;

    if (wind > 15.0)
    {
        windCoincides = readYesNo(
            "Направление ветра совпадает с направлением возможного "
            "самопроизвольного движения? (y/n): "
        );
    }

    cout << "\nВАЖНО:\n";
    cout << "Замасленность и ветер не изменяют расчет по массе.\n";
    cout << "Они учитываются отдельным расчетом по Приложению №12 ИДП.\n";

    if (!readYesNo("Выполнить расчет закрепления по ИДП сейчас? (y/n): "))
        return;

    int axlesForIdp = input.axles;

    if (axlesForIdp <= 0)
    {
        axlesForIdp = readInt(
            "Для ИДП введите количество осей закрепляемой группы: ",
            1
        );
    }

    modeAppendix12(
        axlesForIdp,
        true,
        oily,
        wind,
        windCoincides
    );
}


void modeAppendix12(
    int prefilledAxles,
    bool hasPrefilledConditions,
    bool prefilledOily,
    double prefilledWind,
    bool prefilledWindCoincides
)
{
    cout
        << "\n=============================================\n";

    cout
        << "       ЗАКРЕПЛЕНИЕ "
        << "ПО ПРИЛОЖЕНИЮ №12 ИДП\n";

    cout
        << "=============================================\n";


    // --------------------------------------------------
    // КОЛИЧЕСТВО ОСЕЙ
    // --------------------------------------------------

    int axles =
        prefilledAxles;


    // Если режим запущен отдельно
    if (axles <= 0)
    {
        axles =
            readInt(
                "Количество осей "
                "закрепляемой группы: ",
                1
            );
    }


    // --------------------------------------------------
    // ПРОФИЛЬ ПУТИ
    // --------------------------------------------------

    cout << "\nПрофиль пути:\n";


    cout
        << "1 - обычный / "
        << "известен расчетный уклон\n";


    cout
        << "2 - ломаный профиль, "
        << "вагоны занимают весь путь\n";


    cout
        << "    (введите средний "
        << "уклон пути)\n";


    cout
        << "3 - вагоны стоят "
        << "на отдельном отрезке\n";


    cout
        << "    (введите фактический "
        << "уклон отрезка)\n";


    int profileMode =
        readChoice(
            "Ваш выбор: ",
            1,
            3
        );


    // --------------------------------------------------
    // УКЛОН
    // --------------------------------------------------

    double slope =
        readDouble(
            "Введите используемый уклон, "
            "промилле: ",
            0.0,
            true
        );


    // --------------------------------------------------
    // УСЛОВИЯ
    // --------------------------------------------------

    bool isOily;

    double wind;

    bool windCoincides;


    // Если пришли из расчета по массе
    if (hasPrefilledConditions)
    {
        isOily =
            prefilledOily;


        wind =
            prefilledWind;


        windCoincides =
            prefilledWindCoincides;


        cout
            << "\nПеренесенные условия:\n";


        cout
            << "Замасленные рельсы: "
            << (
                isOily
                ? "да"
                : "нет"
            )
            << "\n";


        cout
            << "Ветер: "
            << wind
            << " м/с\n";


        if (wind > 15.0)
        {
            cout
                << "Совпадение с направлением "
                << "возможного ухода: "
                << (
                    windCoincides
                    ? "да"
                    : "нет"
                )
                << "\n";
        }
    }


    // Если режим ИДП запущен отдельно
    else
    {
        isOily =
            readYesNo(
                "Замасленные рельсы? (y/n): "
            );


        wind =
            readDouble(
                "Скорость ветра, м/с "
                "(0 если не учитывать): ",
                0.0,
                true
            );


        windCoincides =
            false;


        if (wind > 15.0)
        {
            windCoincides =
                readYesNo(
                    "Направление ветра совпадает "
                    "с направлением возможного "
                    "самопроизвольного движения? "
                    "(y/n): "
                );
        }
    }


    // --------------------------------------------------
    // ОСНОВНОЙ РАСЧЕТ
    // --------------------------------------------------

    double baseExact =
        0.0;


    int formula =
        0;


    int mainShoes =
        0;


    int oppositeShoes =
        0;


    // ==================================================
    // УКЛОН ДО 0.5 ПРОМИЛЛЕ ВКЛЮЧИТЕЛЬНО
    // ==================================================

    if (slope <= 0.5)
    {
        // По одному башмаку с каждой стороны
        baseExact =
            2.0;


        // Замасленные рельсы
        if (isOily)
        {
            baseExact *=
                1.5;
        }


        mainShoes =
            ceilInt(
                baseExact
            );
    }


    // ==================================================
    // УКЛОН БОЛЕЕ 0.5 ПРОМИЛЛЕ
    // ==================================================

    else
    {
        cout
            << "\nВыберите расчетную формулу:\n\n";


        cout
            << "1 - K = n * "
            << "(1.5*i + 1) / 200\n";


        cout
            << "    Однородный состав "
            << "или башмаки укладываются "
            << "под вагоны\n";


        cout
            << "    с нагрузкой 15 т/ось "
            << "и более, либо под "
            << "наиболее тяжелые.\n\n";


        cout
            << "2 - K = n * "
            << "(4*i + 1) / 200\n";


        cout
            << "    Смешанный состав, "
            << "если башмаки укладываются "
            << "под порожние\n";


        cout
            << "    или более легкие вагоны, "
            << "либо нагрузка "
            << "на ось неизвестна.\n";


        formula =
            readChoice(
                "Ваш выбор: ",
                1,
                2
            );


        // Формула №1
        if (formula == 1)
        {
            baseExact =
                axles *
                (
                    1.5 *
                    slope +
                    1.0
                )
                /
                200.0;
        }


        // Формула №2
        else
        {
            baseExact =
                axles *
                (
                    4.0 *
                    slope +
                    1.0
                )
                /
                200.0;
        }


        // Замасленные рельсы
        if (isOily)
        {
            baseExact *=
                1.5;
        }


        mainShoes =
            ceilInt(
                baseExact
            );


        // Если уклон больше 0.5,
        // но не более 1 промилле
        if (slope <= 1.0)
        {
            oppositeShoes =
                1;
        }
    }


    // --------------------------------------------------
    // ВЕТЕР
    // --------------------------------------------------

    int windShoes =
        0;


    if (windCoincides)
    {
        double windExact =
            0.0;


        // Штормовой ветер
        if (wind > 21.0)
        {
            windExact =
                axles *
                7.0 /
                200.0;
        }


        // Сильный ветер
        else if (wind > 15.0)
        {
            windExact =
                axles *
                3.0 /
                200.0;
        }


        windShoes =
            ceilInt(
                windExact
            );
    }


    // --------------------------------------------------
    // ИТОГО БАШМАКОВ
    // --------------------------------------------------

    int totalShoes =
        mainShoes +
        oppositeShoes +
        windShoes;


    // --------------------------------------------------
    // ФАКТИЧЕСКОЕ НАЛИЧИЕ
    // --------------------------------------------------

    int availableShoes =
        readInt(
            "Количество доступных "
            "тормозных башмаков: ",
            0
        );


    cout
        << fixed
        << setprecision(2);


    cout
        << "\n=============================================\n";

    cout
        << "                  РЕЗУЛЬТАТ\n";

    cout
        << "=============================================\n";


    cout
        << "Количество осей: "
        << axles
        << "\n";


    cout
        << "Уклон: "
        << slope
        << " промилле\n";


    // --------------------------------------------------
    // ПРОФИЛЬ
    // --------------------------------------------------

    if (profileMode == 2)
    {
        cout
            << "Использован средний уклон "
            << "ломаного профиля всего пути.\n";
    }


    else if (profileMode == 3)
    {
        cout
            << "Использован фактический уклон "
            << "отдельного отрезка пути.\n";
    }


    // --------------------------------------------------
    // МАЛЫЙ УКЛОН
    // --------------------------------------------------

    if (slope <= 0.5)
    {
        cout
            << "\nБазовая норма: "
            << "по одному башмаку "
            << "с каждой стороны.\n";


        if (isOily)
        {
            cout
                << "Замасленные рельсы: "
                << "норма увеличена в 1.5 раза.\n";


            cout
                << "Расчетное значение "
                << "после коэффициента: "
                << baseExact
                << "\n";


            cout
                << "Принято вверх: "
                << mainShoes
                << " шт.\n";


            cout
                << "Распределение увеличенного "
                << "количества по сторонам\n";


            cout
                << "следует сверять "
                << "с локальным нормативным актом.\n";
        }
    }


    // --------------------------------------------------
    // ФОРМУЛА
    // --------------------------------------------------

    else
    {
        cout
            << "\nИспользована формула №"
            << formula
            << "\n";


        cout
            << "Расчетное значение "
            << "после коэффициентов: "
            << baseExact
            << "\n";


        cout
            << "Со стороны спуска: "
            << mainShoes
            << " шт.\n";


        if (oppositeShoes > 0)
        {
            cout
                << "С противоположной стороны: "
                << oppositeShoes
                << " шт.\n";
        }
    }


    // --------------------------------------------------
    // ВЕТЕР
    // --------------------------------------------------

    if (windShoes > 0)
    {
        cout
            << "Дополнительно из-за ветра: "
            << windShoes
            << " шт.\n";
    }


    // --------------------------------------------------
    // ОБЩИЙ РЕЗУЛЬТАТ
    // --------------------------------------------------

    cout
        << "\nИТОГО требуется: "
        << totalShoes
        << " тормозных башмаков.\n";


    cout
        << "Доступно: "
        << availableShoes
        << " шт.\n";


    // ==================================================
    // БАШМАКОВ ХВАТАЕТ
    // ==================================================

    if (
        availableShoes >=
        totalShoes
    )
    {
        cout
            << "\nЗАКРЕПЛЕНИЕ "
            << "ПО КОЛИЧЕСТВУ БАШМАКОВ "
            << "ОБЕСПЕЧЕНО.\n";


        cout
            << "Запас: "
            << availableShoes -
               totalShoes
            << " шт.\n";
    }


    // ==================================================
    // БАШМАКОВ НЕ ХВАТАЕТ
    // ==================================================

    else
    {
        int missingShoes =
            totalShoes -
            availableShoes;


        // 5 тормозных осей
        // заменяют 1 башмак
        int substituteBrakeAxles =
            missingShoes *
            5;


        cout
            << "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n";

        cout
            << "       ТОРМОЗНЫХ БАШМАКОВ НЕДОСТАТОЧНО\n";

        cout
            << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n";


        cout
            << "Не хватает: "
            << missingShoes
            << " башмак(ов).\n";


        cout
            << "По нормативу: "
            << "5 тормозных осей = "
            << "1 тормозной башмак.\n";


        cout
            << "Для компенсации дефицита требуется: "
            << substituteBrakeAxles
            << " тормозных осей.\n";


        int axlesPerHandBrake =
            readInt(
                "\nНа сколько тормозных осей "
                "действует ручной тормоз "
                "одного вагона? ",
                1
            );


        int neededWagons =
            ceilInt(
                static_cast<double>(
                    substituteBrakeAxles
                )
                /
                axlesPerHandBrake
            );


        cout
            << "\nНеобходимо включить "
            << "ручные тормоза минимум на "
            << neededWagons
            << " вагоне(ах).\n";


        cout
            << "При этом будет заторможено "
            << "не менее "
            << neededWagons *
               axlesPerHandBrake
            << " тормозных осей.\n";


        cout << "\nВАЖНО:\n";


        cout
            << "Замена тормозных башмаков "
            << "стояночными тормозами "
            << "применяется\n";


        cout
            << "только в случаях, "
            << "предусмотренных нормативным "
            << "и локальным порядком.\n";
    }


    // --------------------------------------------------
    // ИСТОЧНИК
    // --------------------------------------------------

    cout
        << "\n=============================================\n";


    cout
        << "РАСЧЕТ ВЫПОЛНЕН ПО "
        << "ПРИЛОЖЕНИЮ №12 ИДП";


    if (formula != 0)
    {
        cout
            << ", ФОРМУЛА №"
            << formula;
    }


    cout
        << "\n=============================================\n";
}

// ======================================================
// ГЛАВНОЕ МЕНЮ
// ======================================================

int main()
{
    setlocale(LC_ALL, "");

    while (true)
    {
        cout << "\n\n=============================================\n";
        cout << "     ЖЕЛЕЗНОДОРОЖНЫЙ ТОРМОЗНОЙ КАЛЬКУЛЯТОР\n";
        cout << "=============================================\n";
        cout << "1 - Расчет по массе\n";
        cout << "2 - Закрепление по Приложению №12 ИДП\n";
        cout << "3 - История последних расчетов по массе\n";
        cout << "4 - Показать базу локомотивов\n";
        cout << "0 - Выход\n";

        int mode = readChoice("Выберите режим: ", 0, 4);

        if (mode == 0)
        {
            cout << "\nРабота завершена.\n";
            break;
        }
        else if (mode == 1)
        {
            modeMass();
        }
        else if (mode == 2)
        {
            modeAppendix12(0, false, false, 0.0, false);
        }
        else if (mode == 3)
        {
            showHistory();
        }
        else
        {
            printLocomotiveDatabase();
        }
    }

    return 0;
}
